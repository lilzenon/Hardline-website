const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/ShopPageMobile-K0pcLtT1.js","assets/index-DB2e_DQB.js","assets/vendor-ViNJc2wV.js","assets/index-BPM0BZxC.css","assets/MobileNavigation-BgRHJzor.js","assets/SocialMediaButtons-DO-gOt5V.js","assets/Footer-kgPE17LS.js","assets/CartIcon-D45Puinp.js","assets/shopService-d0_ZfhGH.js","assets/apiConfig-DLPjctRA.js","assets/useSEO-D4DReJvE.js","assets/Breadcrumb-DYt2TC_4.js"])))=>i.map(i=>d[i]);
import{a as P,j as e,B as z,_ as O}from"./index-DB2e_DQB.js";import{b as n}from"./vendor-ViNJc2wV.js";import{a as R,D as H,F as U}from"./Footer-kgPE17LS.js";import{C as A,a as D}from"./CartIcon-D45Puinp.js";import{f as N}from"./shopService-d0_ZfhGH.js";import{u as $}from"./useSEO-D4DReJvE.js";import{B as V}from"./Breadcrumb-DYt2TC_4.js";const Y=t=>{window.navigateWithTransition?window.navigateWithTransition(t):window.location.href=t},l={container:{background:"transparent",border:"none",borderRadius:"0",overflow:"visible",cursor:"pointer",position:"relative"},containerHover:{},imageContainer:{position:"relative",width:"100%",paddingBottom:"133%",overflow:"hidden",backgroundColor:"rgba(30, 30, 30, 0.5)",borderRadius:"4px"},scrollContainer:{position:"absolute",top:0,left:0,width:"100%",height:"100%",display:"flex",overflowX:"auto",scrollSnapType:"x mandatory",scrollbarWidth:"none",msOverflowStyle:"none",WebkitOverflowScrolling:"touch"},imageWrapper:{flex:"0 0 100%",minWidth:"100%",width:"100%",height:"100%",scrollSnapAlign:"start",scrollSnapStop:"always",position:"relative",margin:0,padding:0},image:{width:"100%",height:"100%",objectFit:"cover",transition:"transform 300ms ease"},imageHover:{transform:"scale(1.03)"},content:{padding:"8px 0 0 0"},title:{fontFamily:"Inter, sans-serif",fontWeight:500,fontSize:"13px",lineHeight:"1.4",color:"#FFFFFF",marginBottom:"4px",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"},price:{fontFamily:"Inter, sans-serif",fontWeight:400,fontSize:"13px",color:"rgba(255, 255, 255, 0.7)",marginBottom:"0"}};function B(t){return new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"}).format(t/100)}function q({product:t,onAddToCart:d}){const[m,c]=n.useState(!1),[h,g]=n.useState(!1),[f,x]=n.useState(!1),[a,u]=n.useState(!1),[v,C]=n.useState(0),{addItem:w,toggleCart:S}=P(),y=t.stock_quantity!==null&&t.stock_quantity<=0,p=t?.sizes&&Array.isArray(t.sizes)&&t.sizes.length>0?t.sizes.filter(i=>i.stock>0).map(i=>i.size):[],j="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 200' fill='%23666'%3E%3Crect width='200' height='200' fill='%23222'/%3E%3Cpath d='M80 70h40v60H80z' fill='%23444'/%3E%3Ccircle cx='95' cy='85' r='8' fill='%23555'/%3E%3Cpath d='M80 130l20-25 10 15 10-10 20 20H80z' fill='%23555'/%3E%3C/svg%3E",b=t.images&&Array.isArray(t.images)&&t.images.length>0?typeof t.images[0]=="object"&&t.images[0].url?t.images.sort((i,o)=>i.is_primary&&!o.is_primary?-1:!i.is_primary&&o.is_primary?1:(i.sort_order||0)-(o.sort_order||0)).map(i=>i.url):t.images:t.image_url?[t.image_url]:[j],T=b.length,_=i=>{const o=i.target.scrollLeft,k=i.target.offsetWidth;if(o<0){i.target.scrollLeft=0;return}const F=Math.round(o/k);F!==v&&C(F)},M=async i=>{if(i.stopPropagation(),!(y||f)){if(p.length>0){u(!a);return}x(!0),await new Promise(o=>setTimeout(o,600)),w(t,1),S(!0),d&&d(t),x(!1)}},W=async(i,o)=>{if(i.stopPropagation(),f)return;x(!0),u(!1),await new Promise(F=>setTimeout(F,600));const k={...t,size:o};w(k,1),S(!0),d&&d(k),x(!1)},E=()=>{Y(`/shop/${t.id}`)},L=p.length>0?`${Math.min(p.length*44+8,220)}px`:"40px";return e.jsxs("div",{style:{...l.container,...m?l.containerHover:{},opacity:0,animation:"fadeInUp 0.6s ease-out forwards"},onClick:E,onMouseEnter:()=>c(!0),onMouseLeave:()=>{c(!1),g(!1),u(!1)},role:"article",tabIndex:0,onKeyDown:i=>{(i.key==="Enter"||i.key===" ")&&(i.preventDefault(),E())},"aria-label":`${t.name} - ${B(t.price)}. Click to view details.`,children:[e.jsx("style",{children:`
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}),e.jsxs("div",{style:l.imageContainer,children:[e.jsxs("div",{style:l.scrollContainer,onScroll:_,className:"no-scrollbar",children:[e.jsx("style",{children:`
            .no-scrollbar::-webkit-scrollbar { display: none; }
            .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
          `}),b.map((i,o)=>e.jsx("div",{style:l.imageWrapper,children:e.jsx("img",{src:i,alt:`${t.name} - Image ${o+1}`,style:{...l.image,...m?l.imageHover:{}},loading:"lazy",draggable:"false"})},o))]}),T>1&&e.jsx("div",{style:{position:"absolute",bottom:"12px",left:"0",right:"0",display:"flex",justifyContent:"center",gap:"6px",zIndex:2,pointerEvents:"none"},children:b.map((i,o)=>e.jsx("div",{style:{width:"6px",height:"6px",borderRadius:"50%",background:o===v?"#FFFFFF":"rgba(255, 255, 255, 0.4)",boxShadow:"0 1px 2px rgba(0,0,0,0.3)",transition:"background 0.2s ease"}},o))}),!y&&e.jsx("div",{style:{position:"absolute",bottom:"12px",right:"12px",height:"40px",width:a?L:"40px",background:"#FFFFFF",borderRadius:a?"20px":"50%",display:"flex",alignItems:"center",justifyContent:"center",cursor:a?"default":"pointer",boxShadow:"0 4px 12px rgba(0,0,0,0.2)",transition:"all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",zIndex:10,overflow:"hidden",padding:a?"0 4px":"0"},onClick:a?i=>i.stopPropagation():M,onMouseEnter:()=>g(!0),onMouseLeave:()=>g(!1),children:f?e.jsx("div",{style:{width:"14px",height:"14px",border:"2px solid rgba(0,0,0,0.1)",borderTop:"2px solid #000",borderRadius:"50%",animation:"spin 0.8s linear infinite",flexShrink:0},children:e.jsx("style",{children:"@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }"})}):a?e.jsxs("div",{style:{display:"flex",gap:"4px",animation:"fadeIn 0.2s ease"},children:[e.jsx("style",{children:"@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }"}),p.map(i=>e.jsx("button",{onClick:o=>W(o,i),style:{minWidth:"36px",height:"32px",border:"none",background:"transparent",borderRadius:"16px",fontFamily:"Inter, sans-serif",fontSize:"13px",fontWeight:700,color:"#000000",cursor:"pointer",padding:"0 8px",transition:"background 0.2s ease"},onMouseEnter:o=>o.currentTarget.style.background="rgba(0,0,0,0.05)",onMouseLeave:o=>o.currentTarget.style.background="transparent",children:i},i))]}):e.jsxs("svg",{width:"20",height:"20",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round",style:{color:"#000000",flexShrink:0},children:[e.jsx("line",{x1:"12",y1:"5",x2:"12",y2:"19"}),e.jsx("line",{x1:"5",y1:"12",x2:"19",y2:"12"})]})})]}),e.jsxs("div",{style:l.content,children:[e.jsx("h3",{style:l.title,children:t.name}),e.jsx("p",{style:l.price,children:y?e.jsx("span",{style:{color:"rgba(255, 255, 255, 0.4)"},children:"Out of Stock"}):B(t.price)})]})]})}const s={container:{display:"grid",gap:"8px",width:"100%"},skeleton:{display:"flex",flexDirection:"column",gap:"12px",width:"100%"},skeletonImage:{width:"100%",aspectRatio:"3/4",background:"rgba(255, 255, 255, 0.05)",borderRadius:"0",animation:"pulse 1.5s ease-in-out infinite"},skeletonContent:{padding:"0 4px"},skeletonTitle:{height:"14px",width:"70%",background:"rgba(255, 255, 255, 0.1)",borderRadius:"2px",marginBottom:"8px"},skeletonPrice:{height:"14px",width:"30%",background:"rgba(255, 255, 255, 0.1)",borderRadius:"2px",marginBottom:"0"},skeletonButton:{display:"none"},emptyState:{gridColumn:"1 / -1",textAlign:"center",padding:"48px 24px",color:"rgba(255, 255, 255, 0.6)",fontFamily:"Inter, sans-serif"},emptyIcon:{fontSize:"48px",marginBottom:"16px"},emptyTitle:{fontSize:"20px",fontWeight:600,color:"#FFFFFF",marginBottom:"8px"},emptyText:{fontSize:"14px",color:"rgba(255, 255, 255, 0.6)"}},G=`
  @keyframes shimmer {
    0% { background-position: -200% 0; }
    100% { background-position: 200% 0; }
  }

  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.7; }
  }

  .shop-product-grid {
    grid-template-columns: repeat(2, 1fr);
    column-gap: 0px; /* Removed gap */
    row-gap: 0px; /* Removed gap */
  }

  @media (min-width: 768px) {
    .shop-product-grid {
      grid-template-columns: repeat(2, 1fr);
      column-gap: 12px;
      row-gap: 16px;
    }
  }

  @media (min-width: 1024px) {
    .shop-product-grid {
      grid-template-columns: repeat(3, 1fr);
      column-gap: 16px;
      row-gap: 24px;
    }
  }

  @media (min-width: 1440px) {
    .shop-product-grid {
      grid-template-columns: repeat(3, 1fr);
      column-gap: 20px;
      row-gap: 32px;
    }
  }
`;function K(){return e.jsxs("div",{style:s.skeleton,children:[e.jsx("div",{style:s.skeletonImage}),e.jsxs("div",{style:s.skeletonContent,children:[e.jsx("div",{style:s.skeletonTitle}),e.jsx("div",{style:s.skeletonPrice}),e.jsx("div",{style:s.skeletonButton})]})]})}function X(){return e.jsxs("div",{style:s.emptyState,children:[e.jsx("div",{style:s.emptyIcon,children:"🛍️"}),e.jsx("h3",{style:s.emptyTitle,children:"No products available"}),e.jsx("p",{style:s.emptyText,children:"Check back soon for new items!"})]})}function J({products:t=[],loading:d=!1,onAddToCart:m}){return e.jsxs(e.Fragment,{children:[e.jsx("style",{children:G}),e.jsx("div",{className:"shop-product-grid",style:s.container,role:"list","aria-label":"Products",children:d?Array.from({length:6}).map((c,h)=>e.jsx(K,{},`skeleton-${h}`)):t.length===0?e.jsx(X,{}):t.map(c=>e.jsx(q,{product:c,onAddToCart:m},c.id))})]})}const Q=n.lazy(()=>O(()=>import("./ShopPageMobile-K0pcLtT1.js"),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11])));function Z({openCart:t=!1}){const[d,m]=n.useState([]),[c,h]=n.useState(!0),[g,f]=n.useState(null),[x,a]=n.useState(!1),[u,v]=n.useState(!0),{isOpen:C,toggleCart:w}=P(),{updateTitle:S,updateDescription:y}=$(),{isMobile:I}=R();n.useEffect(()=>{S("Shop | BOUNCE2BOUNCE"),y("Official BOUNCE2BOUNCE merchandise. Shop exclusive clothing, accessories, and more.")},[]),n.useEffect(()=>{t&&!C&&w()},[t]),n.useEffect(()=>{a(I),v(!1)},[I]);const p=async()=>{try{h(!0),f(null);const r=await N();m(r),console.log("🛍️ Loaded",r.length,"products")}catch(r){console.error("❌ Failed to load products:",r),f(r.message)}finally{h(!1)}};n.useEffect(()=>{p()},[]);const j=r=>{if(window.navigateWithTransition)window.navigateWithTransition(r);else if(window.history&&window.history.pushState){window.history.pushState({},"",r);const b=new PopStateEvent("popstate");window.dispatchEvent(b)}else window.location.href=r};return u?e.jsx(z,{fullScreen:!0,minDisplayTime:300,showMessage:!1}):x?e.jsx(n.Suspense,{fallback:e.jsx(z,{fullScreen:!0,minDisplayTime:300,showMessage:!1}),children:e.jsx(Q,{products:d,loading:c,error:g,onRetry:p})}):e.jsxs(e.Fragment,{children:[e.jsx("style",{children:`
          @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
          }
          @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
          }

          /* Smooth desktop/mobile layout transitions */
          .shop-layout-container {
            transition: opacity 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          }

          @media (prefers-reduced-motion: reduce) {
            * {
              animation-duration: 0.01ms !important;
              animation-iteration-count: 1 !important;
              transition-duration: 0.01ms !important;
            }
          }
        `}),e.jsx("div",{className:"homepage-content shop-layout-container",style:{minHeight:"100vh",background:"#000000",width:"100%"},children:e.jsx("div",{className:"desktop-container",style:{width:"100%",maxWidth:"1400px",margin:"0 auto",position:"relative",background:"#000000",minHeight:"auto",padding:"0 40px",boxSizing:"border-box"},children:e.jsxs("div",{style:{width:"100%",position:"relative"},children:[e.jsxs("div",{style:{position:"relative",display:"grid",gridTemplateColumns:"auto 1fr auto",width:"100%",height:"48px",alignItems:"center",margin:"35px 0 0 0"},children:[e.jsx("img",{crossOrigin:"anonymous",referrerPolicy:"no-referrer",src:"/images/figma-exact/b2b-logo-nav.svg",alt:"B2B Logo",loading:"lazy",decoding:"async",onClick:()=>j("/"),style:{width:"180px",height:"56px",cursor:"pointer",transition:"all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",transform:"scale(1)"},onMouseEnter:r=>{r.currentTarget.style.transform="scale(1.05)",r.currentTarget.style.filter="brightness(1.1)"},onMouseLeave:r=>{r.currentTarget.style.transform="scale(1)",r.currentTarget.style.filter="brightness(1)"}}),e.jsx(H,{currentPage:"Shop",onNavigate:j}),e.jsx("div",{style:{justifySelf:"end"},children:e.jsx(A,{})})]}),e.jsx(V,{items:[{name:"Home",url:"/"},{name:"Shop"}]}),e.jsx("div",{style:{color:"#FFF",fontFamily:"Inter",fontSize:"24px",fontWeight:"600",textAlign:"left",marginTop:"24px",marginBottom:"16px",opacity:0,animation:"fadeInUp 0.8s ease-out 0.2s forwards",paddingLeft:"0px"},children:"Shop"}),e.jsx("div",{style:{width:"100%",margin:"0 auto",paddingBottom:"40px",boxSizing:"border-box",opacity:0,animation:"fadeInUp 0.8s ease-out 0.4s forwards"},children:g?e.jsxs("div",{style:{textAlign:"center",padding:"48px 24px",background:"rgba(22, 22, 22, 0.30)",backdropFilter:"blur(12px)",WebkitBackdropFilter:"blur(12px)",borderRadius:"16px",border:"1px solid rgba(255, 100, 100, 0.3)"},children:[e.jsx("div",{style:{fontSize:"48px",marginBottom:"16px"},children:"⚠️"}),e.jsx("h3",{style:{fontSize:"20px",fontWeight:600,marginBottom:"8px",color:"#FFF"},children:"Unable to load products"}),e.jsx("p",{style:{fontSize:"14px",color:"rgba(255, 255, 255, 0.6)",marginBottom:"16px"},children:g}),e.jsx("button",{onClick:p,style:{padding:"12px 24px",minHeight:"44px",background:"linear-gradient(135deg, #319DFF 0%, #1E7ACC 100%)",border:"none",borderRadius:"8px",fontFamily:"Inter, sans-serif",fontWeight:600,fontSize:"14px",color:"#FFFFFF",cursor:"pointer"},children:"Try Again"})]}):e.jsx(J,{products:d,loading:c})}),e.jsx(U,{compact:!1})]})})}),e.jsx(D,{})]})}const ae=Object.freeze(Object.defineProperty({__proto__:null,default:Z},Symbol.toStringTag,{value:"Module"}));export{J as P,ae as S};
