import{j as n}from"./index-3I2J3uCa.js";import{b as c}from"./vendor-ViNJc2wV.js";import{p as q,b as C,t as B}from"./sanitizer-WkDlJHH-.js";import{u as F,a as I,M as j}from"./useNavHeight-oo9b5dJq.js";import"./SocialMediaButtons-DW-rV2ls.js";const H=()=>{const u=c.useRef(null),g=F(),x=Math.max(g||0,0)+12,{scrollY:v}=I(u.current,{threshold:50,throttleMs:200,passive:!0});c.useEffect(()=>{const a="https://b2b.click",e=`${a}/faq`,t="FAQ BOUNCE2BOUNCE | Electronic Music Events and Experiences",s="Answers to the most common questions about BOUNCE2BOUNCE events, tickets, and the platform.",r=`${a}/images/og-image.png`,o=(p,h,l)=>{let m=document.head.querySelector(`meta[${p}="${h}"]`);m||(m=document.createElement("meta"),m.setAttribute(p,h),document.head.appendChild(m)),m.setAttribute("content",l)},i=(p,h)=>{let l=document.head.querySelector(`link[rel="${p}"]`);l||(l=document.createElement("link"),l.setAttribute("rel",p),document.head.appendChild(l)),l.setAttribute("href",h)};document.title=t,o("name","description",s),o("name","robots","index,follow"),o("property","og:type","website"),o("property","og:site_name","BOUNCE2BOUNCE"),o("property","og:title",t),o("property","og:description",s),o("property","og:url",e),o("property","og:image",r),o("name","twitter:card","summary_large_image"),o("name","twitter:title",t),o("name","twitter:description",s),o("name","twitter:image",r),o("name","twitter:site","@bounce2bounce"),i("canonical",e)},[]);const[d,b]=c.useState([]),[A,f]=c.useState(null);c.useEffect(()=>{const a=async()=>{try{console.log("📥 Loading FAQ content from API (mobile)...");const t=window.location.hostname==="localhost"?"http://localhost:3002":"https://admin.b2b.click",s=await fetch(`${t}/api/settings/faq?ts=${Date.now()}`,{method:"GET",headers:{"Content-Type":"application/json"}});if(s.ok){const r=await s.json();if(console.log("✅ FAQ content loaded from API (mobile):",r),r.success&&r.data){const o=r.data.map(i=>({q:i.question,qText:B(i.question_html||i.question),qHtml:i.question_html||i.question,a:i.answer,aHtml:i.answer_html||i.answer,id:i.id,display_order:i.display_order}));b(o),f(null),console.log("✅ FAQ items set (mobile):",o.length)}else throw new Error("Invalid API response format")}else throw new Error(`API responded with ${s.status}: ${s.statusText}`)}catch(e){console.error("❌ Error loading FAQ content from API (mobile):",e),console.log("🔄 Falling back to default FAQ content (mobile)..."),b([{q:"What is BOUNCE2BOUNCE?",a:"BOUNCE2BOUNCE is a premium live music events platform that connects artists with fans through exclusive experiences and seamless ticket sales."},{q:"How do I buy tickets?",a:"Tickets can be purchased directly through our platform. Simply browse events, click 'Get Tickets' on any event card, and complete your purchase through our secure checkout process."},{q:"What payment methods do you accept?",a:"We accept all major credit cards, PayPal, and Apple Pay for secure and convenient transactions."},{q:"Is BOUNCE2BOUNCE mobile-friendly?",a:"Yes, BOUNCE2BOUNCE features a mobile-first design optimized for iOS Safari and all browsers, providing a seamless mobile experience for event discovery and ticket purchasing."},{q:"How do I contact BOUNCE2BOUNCE?",a:"You can reach us at info@bounce2bounce.com for general inquiries or events@bounce2bounce.com for event-related questions and artist promotion opportunities."}]),f("Using default FAQ content. API connection unavailable.")}};q(),a()},[]);const[y,w]=c.useState(null),k=a=>w(e=>e===a?null:a),E=a=>{if(a==="/faq"){window.scrollTo({top:0,behavior:"smooth"});return}window.location.href=a};return c.useEffect(()=>{const a="ld-json-faq",e=document.getElementById(a);e&&e.remove();const t=[{q:"What is Bounce2Bounce?",a:"Bounce2Bounce is a comprehensive event management platform that helps you create, manage, and promote events with ease."},{q:"How do I create an event?",a:"Simply log into your dashboard, click 'Create Event', and follow our step-by-step wizard to set up your event details, ticketing, and promotion."}],s=d&&d.length?d:t,r=document.createElement("script");r.type="application/ld+json",r.id=a;const o=s.map(i=>({"@type":"Question",name:i.q,acceptedAnswer:{"@type":"Answer",text:i.a}}));r.text=JSON.stringify({"@context":"https://schema.org","@type":"FAQPage",mainEntity:o}),document.head.appendChild(r)},[d]),n.jsxs("div",{style:{width:"100vw",height:"100vh",background:"#000000",position:"relative",overflow:"hidden",fontFamily:"Inter, sans-serif"},children:[n.jsxs("div",{style:{width:"430px",height:"932px",maxWidth:"100vw",maxHeight:"100vh",margin:"0 auto",background:"#000000",position:"relative",display:"flex",flexDirection:"column",overflow:"hidden",overscrollBehavior:"contain"},"aria-label":"Mobile FAQ page content",children:[n.jsx(j,{currentPage:"faq",scrollY:v,onNavigate:E}),n.jsx("div",{ref:u,className:"mobile-content-container mobile-content-fade",style:{flex:"1 1 auto",width:"100%",background:"#000000",display:"flex",flexDirection:"column",justifyContent:"flex-start",alignItems:"center",paddingTop:x,boxSizing:"border-box",overflow:"auto",overflowX:"hidden",WebkitOverflowScrolling:"touch",scrollBehavior:"smooth",overscrollBehavior:"contain",overscrollBehaviorY:"contain",overscrollBehaviorX:"none",touchAction:"pan-y",transform:"translateZ(0)",willChange:"auto",backfaceVisibility:"hidden",WebkitBackfaceVisibility:"hidden"},role:"main","aria-label":"FAQ page content",children:n.jsxs("div",{style:{width:"100%",maxWidth:"430px",padding:"0px 24px 48px 24px",boxSizing:"border-box"},children:[n.jsx("h1",{style:{margin:"16px 0 24px 0",fontSize:"32px",fontWeight:800,lineHeight:1.15,letterSpacing:"-0.02em",textAlign:"center",color:"#FFFFFF"},children:"FAQ"}),n.jsx("div",{style:{padding:"0 10px"},children:d.map((a,e)=>{const t=y===e;return n.jsxs("div",{style:{background:"rgba(22,22,22,0.4)",border:"1px solid rgba(56,56,56,0.3)",backdropFilter:"blur(20px)",WebkitBackdropFilter:"blur(20px)",borderRadius:"14px",marginBottom:"10px",overflow:"hidden",transition:"transform 0.25s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.25s cubic-bezier(0.4, 0, 0.2, 1)",willChange:"transform, opacity",transform:t?"translateZ(0) scale(1.01)":"translateZ(0) scale(1)",boxShadow:t?"0 8px 24px rgba(0,0,0,0.25)":"0 4px 12px rgba(0,0,0,0.15)",opacity:0,animation:`fadeInUp 0.4s ease-out ${.1+e*.05}s forwards`},children:[n.jsxs("button",{onClick:()=>k(e),id:`faq-mobile-question-${e}`,"aria-expanded":t,"aria-controls":`faq-mobile-answer-${e}`,style:{width:"100%",display:"flex",justifyContent:"space-between",alignItems:"center",padding:"20px 24px",background:"transparent",color:"#FFF",border:"none",cursor:"pointer",fontSize:"18px",lineHeight:1.3,fontWeight:600,minHeight:"44px"},children:[n.jsx("span",{className:"rich-text-content",children:a.qText}),n.jsx("span",{className:"faq-arrow","aria-hidden":"true",style:{display:"inline-flex",width:"20px",height:"20px",alignItems:"center",justifyContent:"center",transform:t?"rotate(180deg) translateZ(0)":"rotate(0deg) translateZ(0)",transformOrigin:"50% 50%"},children:n.jsx("svg",{width:"20",height:"20",viewBox:"0 0 24 24",xmlns:"http://www.w3.org/2000/svg",style:{display:"block"},children:n.jsx("path",{d:"M6 9l6 6 6-6",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})})})]}),n.jsx("div",{id:`faq-mobile-answer-${e}`,role:"region","aria-labelledby":`faq-mobile-question-${e}`,style:{maxHeight:t?"min(70vh, 560px)":"0px",transition:"max-height 0.28s cubic-bezier(0.4, 0, 0.2, 1), padding 0.28s cubic-bezier(0.4, 0, 0.2, 1)",willChange:"max-height, padding",overflow:"hidden"},children:n.jsx("div",{style:{padding:t?"12px 24px 24px 24px":"0 24px",color:"rgba(255,255,255,0.84)",borderTop:"1px solid rgba(56,56,56,0.3)",borderTopColor:t?"rgba(56,56,56,0.3)":"rgba(56,56,56,0)",opacity:t?1:0,transform:t?"translateY(0)":"translateY(4px)",transition:"opacity 0.28s cubic-bezier(0.4, 0, 0.2, 1) 0.06s, transform 0.28s cubic-bezier(0.4, 0, 0.2, 1) 0.06s, border-top-color 0.28s ease 0.04s"},children:n.jsx("div",{className:"faq-answer-scroll",style:{maxHeight:"min(68vh, 520px)",overflowY:"auto",overflowX:"hidden",WebkitOverflowScrolling:"touch"},children:n.jsx("div",{className:"rich-text-content",dangerouslySetInnerHTML:{__html:C(a.aHtml||a.a)}})})})})]},e)})})]})})]}),n.jsx("style",{children:`
        .mobile-content-fade {
          animation: fadeInUp 0.6s ease-out;
        }

        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        /* Global mobile scroll behavior fixes to prevent pull-to-refresh */
        @media (max-width: 767px) {
          html, body {
            overscroll-behavior-y: contain !important;
            -webkit-overscroll-behavior-y: contain !important;
            overscroll-behavior-x: none !important;
            touch-action: pan-y !important;
          }
        }

        /* Scrolling optimizations */
        .mobile-content-container {
          -webkit-overflow-scrolling: touch;
          scroll-behavior: smooth;
          overscroll-behavior: contain;
          overscroll-behavior-y: contain;
          overscroll-behavior-x: none;
          touch-action: pan-y;
          contain: layout style;
          will-change: auto;
          transform: translateZ(0);
          -webkit-transform: translateZ(0);
          backface-visibility: hidden;
          -webkit-backface-visibility: hidden;
        }

        /* Ensure content is scrollable */
        .mobile-content-container::-webkit-scrollbar {
          display: none; /* Hide scrollbar for cleaner look */
        }

        .mobile-content-container {
          -ms-overflow-style: none; /* IE and Edge */
          scrollbar-width: none; /* Firefox */
        }

        /* Modern animated arrow for expand/collapse */
        .faq-arrow {
          transition: transform 240ms cubic-bezier(0.4, 0, 0.2, 1);
          will-change: transform;
          transform: translateZ(0);
          -webkit-transform: translateZ(0);
          backface-visibility: hidden;
          -webkit-backface-visibility: hidden;
        }


        @media (prefers-reduced-motion: reduce) {
          * { animation-duration: 0.01ms !important; animation-iteration-count: 1 !important; transition-duration: 0.01ms !important; }
        }
      `})]})};export{H as default};
